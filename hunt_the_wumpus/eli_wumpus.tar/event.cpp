#include "event.h"

/*
* shhhhh.... this is a ghost class,
* ain't nobody comes round here no more
*/

Event::Event() {

}

Event::~Event() {

}

Event::Event(const Event& e) {

}

Event& Event::operator=(const Event& e) {
    return *this;
}