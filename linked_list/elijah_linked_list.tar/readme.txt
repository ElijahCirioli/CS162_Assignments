Linked list 
By Elijah Cirioli

My own implementation of a forward list in C++
that includes a simple demo program that allows 
you to add numbers to a list, sort it, and print
its contents through the terminal.

I did both of the extra credit opportunities
meaning that my classes are implemented as
templates. In my demo program you can choose to
make a list of either signed or unsigned integers
but more options are possible. My ascending sort
is implemented through recursive merge sort and
my descending sort is implemented through
recursive seleciton sort, which is the other 
extra credit opportunity.

The makefile compiles the program into list.exe